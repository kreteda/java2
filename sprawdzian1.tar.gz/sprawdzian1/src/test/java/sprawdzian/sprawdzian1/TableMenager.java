package sprawdzian.sprawdzian1;

public class TableMenager extends Table{

Table a = new Table();

int b = 5;
 
a.gets();




	
	
	
}