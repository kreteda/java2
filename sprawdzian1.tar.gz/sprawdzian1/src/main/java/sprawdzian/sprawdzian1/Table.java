package sprawdzian.sprawdzian1;

public class Table {

int s;
float b ;
double o;


public int gets1() {
	return s;
}

public float getb1() {
	return b;
}

public int dodajs(int a)
{
	return s=s+a;
	
}

public float dodajf(float a)
{
	return b=b+a;
}

public double dodajd(double a)
{
	return o=o+a;
}

public static void main(String[] args){
	
 
}

 

}